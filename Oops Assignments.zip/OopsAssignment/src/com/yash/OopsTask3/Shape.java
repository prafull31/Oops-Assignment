package com.yash.OopsTask3;

public interface Shape 
{
   void area();
  
}
