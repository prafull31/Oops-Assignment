package com.yash.OopsTask6;

public abstract class Sub extends sum{

	@Override
	void sub(int a, int b) {
		int c=a-b;
		System.out.println("Sub: "+c);
		
	}

	

}
