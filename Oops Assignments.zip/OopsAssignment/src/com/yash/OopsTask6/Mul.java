package com.yash.OopsTask6;


public abstract class Mul extends Sub{

	@Override
	void mul(int a, int b) {
		int c=a*b;
		System.out.println("Mul: "+c);
		
	}



}

