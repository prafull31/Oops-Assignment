package com.yash.OopsTask1;

public class Person 
{
  private int Pid;
  private String pname;
  private String paddress;
  private int dob;
public int getPid() {
	return Pid;
}
public void setPid(int pid) {
	Pid = pid;
}
public String getPname() {
	return pname;
}
public void setPname(String pname) {
	this.pname = pname;
}
public String getPaddress() {
	return paddress;
}
public void setPaddress(String paddress) {
	this.paddress = paddress;
}
public int getDob() {
	return dob;
}
public void setDob(int dob) {
	this.dob = dob;
}
  
  
}
