package com.yash.Oopstask2;

public interface Shape {
	public double area();

}
